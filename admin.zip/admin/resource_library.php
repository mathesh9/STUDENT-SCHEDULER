<?php
ob_start(); // Start output buffering at the very beginning

if (session_status() === PHP_SESSION_NONE) {
    session_start(); // Ensure the session is started only if not already active
}

// Check if user is authenticated (simulated for demo)
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 1; // Simulated user ID
}

$user_id = $_SESSION['user_id'];

// Initialize session variables to store submitted resources (if not already initialized)
if (!isset($_SESSION['submitted_resources'])) {
    $_SESSION['submitted_resources'] = array();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $link = $_POST['link'];
    $note = $_POST['note'];

    // Simulate file upload success (if needed)
    $file_path = '';
    if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
        $file_name = basename($_FILES['file']['name']);
        $upload_dir = '../uploads/'; // Ensure this directory exists and is writable
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true); // Create directory if it doesn't exist
        }
        $file_path = $upload_dir . $file_name;
        // Simulate file upload success without moving file
    }

    // Store submitted resource in session specific to the user
    $_SESSION['submitted_resources'][] = array(
        'user_id' => $user_id,
        'title' => $title,
        'description' => $description,
        'file_path' => $file_path,
        'link' => $link,
        'note' => $note,
        'date_added' => time() // Store timestamp of submission
    );

    $_SESSION['resource_added'] = true; // Set session variable to indicate success
}
?>
<!DOCTYPE html>
<html lang="en">
<?php require_once('inc/header.php'); ?>
<body>
<?php require_once('inc/navigation.php'); ?>
<div class="container">
    <h2>Resource Library</h2>
    <?php if (isset($_SESSION['resource_added']) && $_SESSION['resource_added']): ?>
        <div class="alert alert-success" role="alert">
            Resource added successfully! <a href="resource_library.php">Refresh</a> to see the updated list.
        </div>
        <?php unset($_SESSION['resource_added']); // Clear success message ?>
    <?php endif; ?>
    <form action="resource_library.php" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="title">Title:</label>
            <input type="text" class="form-control" id="title" name="title" required>
        </div>
        <div class="form-group">
            <label for="description">Description:</label>
            <textarea class="form-control" id="description" name="description" required></textarea>
        </div>
        <div class="form-group">
            <label for="file">Upload File:</label>
            <input type="file" class="form-control-file" id="file" name="file">
        </div>
        <div class="form-group">
            <label for="link">Link:</label>
            <input type="url" class="form-control" id="link" name="link">
        </div>
        <div class="form-group">
            <label for="note">Note:</label>
            <textarea class="form-control" id="note" name="note"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Add Resource</button>
    </form>
    <hr>
    <h3>My Resources</h3>
    <div class="list-group">
        <?php
        // Display resources added within the last minute
        $now = time();
        foreach ($_SESSION['submitted_resources'] as $key => $resource) {
            if (isset($resource['user_id']) && $resource['user_id'] == $user_id && ($now - $resource['date_added']) <= 60) { // Check if resource is within last minute
                ?>
                <div class="list-group-item">
                    <h5><?php echo htmlspecialchars($resource['title']); ?></h5>
                    <p><?php echo nl2br(htmlspecialchars($resource['description'])); ?></p>
                    <?php if (!empty($resource['file_path'])): ?>
                        <p><a href="<?php echo htmlspecialchars($resource['file_path']); ?>" target="_blank">Download File</a></p>
                    <?php endif; ?>
                    <?php if (!empty($resource['link'])): ?>
                        <p><a href="<?php echo htmlspecialchars($resource['link']); ?>" target="_blank">Visit Link</a></p>
                    <?php endif; ?>
                    <?php if (!empty($resource['note'])): ?>
                        <p><?php echo nl2br(htmlspecialchars($resource['note'])); ?></p>
                    <?php endif; ?>
                    <small class="text-muted">Added on <?php echo htmlspecialchars(date('Y-m-d H:i:s', $resource['date_added'])); ?></small>
                </div>
                <?php
            } else {
                // Remove resource from session if it's older than 1 minute
                unset($_SESSION['submitted_resources'][$key]);
            }
        }
        ?>
    </div>
</div>
<?php require_once('inc/footer.php'); ?>
</body>
</html>
<?php
ob_end_flush(); // Flush the output buffer and send output to browser
?>
